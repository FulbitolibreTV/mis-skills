# Integración YouTube Agent para `FulbitolibreTV/mis-skills`

Este ZIP es una **actualización parcial del repositorio**, no un reemplazo de todo el proyecto.
Contiene únicamente los archivos nuevos o modificados. Conserva las carpetas previas `skills/`, `plugins/`, `guias/` y sus contenidos.

## Archivos preparados

- `.claude-plugin/marketplace.json`: añade `./skills/youtube-agent` al plugin `skills-video`.
- `README.md`: describe la skill, mantiene la estructura existente y agrega créditos MIT.
- `skills/youtube-agent/`: skill unificada con once submódulos y seis scripts Python.
- `zips/youtube-agent-v1.0.1.zip`: ZIP de la skill para Claude web/app.
- `zips/youtube-agent-plugin-v1.0.1.zip`: ZIP plugin para Claude Code.
- `youtube-agent-skill-main.zip`: sustitución corregida del ZIP antiguo en la raíz.

## Aplicación

Cuando la conexión de GitHub permita escribir, subir estos archivos **conservando sus rutas** o
aplicar el archivo de parche a la copia del repositorio. No elimines otros archivos del repo.
No se ha subido esta integración directamente a GitHub porque el conector devolvió un error 403
(Resource not accessible by integration) tanto al crear una rama como al crear un archivo.

### Uso una vez integrada

- Claude Code: `/plugin marketplace add FulbitolibreTV/mis-skills` y luego
  `/plugin install skills-video --marketplace FulbitolibreTV/mis-skills`.
- Claude web o app: subir `zips/youtube-agent-v1.0.1.zip` como una skill.

**Créditos:** la obra original YouTube Agent es de Jake Schincariol, licencia MIT.
**Límites:** no publica automáticamente, no accede a YouTube sin datos proporcionados y los scripts
requieren un entorno que ejecute Python.
